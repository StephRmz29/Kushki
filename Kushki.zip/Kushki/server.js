const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const axios = require('axios');

const app = express();
const port = 3003;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

// Define la ruta para servir el archivo index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Define la ruta para procesar el pago
app.post('/make-payment', async (req, res) => {
    const token = req.body.token;

    try {
        const response = await axios.post('https://api.kushkipagos.com/charges', {
            "token": token,
            "totalAmount": 100.50,
            "currency": "USD",
            "installmentsType": "single"
        }, {
            headers: {
                'Public-Merchant-Id': '20000000102869150000'
            }
        });

        console.log('Respuesta de la solicitud de pago:', response.data); // Agrega este console.log

        res.json({ message: response.data.message });
    } catch (error) {
        res.status(400).json({ message: error.response.data.message });
    }
});

// Inicia el servidor
app.listen(port, () => {
    console.log(`Servidor iniciado en http://localhost:${port}`);
});
